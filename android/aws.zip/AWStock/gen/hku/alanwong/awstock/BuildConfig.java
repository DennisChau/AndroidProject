/** Automatically generated file. DO NOT MODIFY */
package hku.alanwong.awstock;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}